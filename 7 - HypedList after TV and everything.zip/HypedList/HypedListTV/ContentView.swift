//
//  ContentView.swift
//  HypedListTV
//
//  Created by ZappyCode on 10/21/20.
//

import SwiftUI

struct ContentView: View {
    
    @ObservedObject var data = DataController.shared
    
    var body: some View {
        TabView {
            HypedEventTVListView(hypedEvents: data.upcomingHypedEvents, noEventsText: "Nothing to look forward to 😥\nCreate an event or check out the Discover tab!")
                .tabItem {
                    Image(systemName:"calendar")
                    Text("Upcoming")
                }
            
            HypedEventTVListView(hypedEvents: data.discoverHypedEvents, noEventsText: "Loading some awesome stuff for ya!", isDiscover: true)
                .tabItem {
                    Image(systemName:"magnifyingglass")
                    Text("Discover")
                }
            
            HypedEventTVListView(hypedEvents: data.pastHypedEvents, noEventsText: "No events have passed yet, you should add some more things!")
                .tabItem {
                    Image(systemName:"gobackward")
                    Text("Past")
                }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

//
//  HypedListTVApp.swift
//  HypedListTV
//
//  Created by ZappyCode on 10/21/20.
//

import SwiftUI

@main
struct HypedListTVApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .onAppear {
                    DataController.shared.loadData()
                    DataController.shared.getDiscoverEvents()
                }
        }
    }
}
